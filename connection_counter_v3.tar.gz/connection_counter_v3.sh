#!/bin/bash

isRunning="$(ps -aef | grep check_nm_12324 | grep -v grep | wc -l)"
procName="$(ps -aef | grep check_nm_12324 | grep -v grep  | awk '{print $2}')"
re='^[0-9]+$'
#read hrs

cd "$(dirname "$0")"

FILE=check_nm_12324

if [ ! -f "$FILE" ]; then
	    echo "$FILE does not exist"


elif ! [[ $2 =~ $re && $3 =~ $re ]]
	then
	echo "Please enter values for hours & ports , eg : ./check_nm_12324 [hours] [http port] [memcached port]"
	else
		case "$1" in 
			[1-9])
				secs="$(($1 * 60 * 60))"
					if [ $isRunning -eq 0 ] 
							then
							nohup ./check_nm_12324 $secs $2 $3 1>/dev/null 2>/dev/null &
							echo "The script will run for $1 hours and collect connection count data in a file named connections_log_xxxxx.txt "
					else
							echo "Process already running with PID $procName"
					fi
			;;
			*)
			echo -e "Please enter no of hours between 1 and 9."
			exit 1
			;;
		esac
fi
